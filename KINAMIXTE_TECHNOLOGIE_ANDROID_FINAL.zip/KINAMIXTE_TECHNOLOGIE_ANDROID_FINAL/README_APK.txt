KINAMIXTE TECHNOLOGIE — APPLICATION ANDROID PRO v2.0.0

Ce projet contient une application Android moderne basée sur le site KINAMIXTE TECHNOLOGIE.

FONCTIONS
- Icône de l'application basée sur le logo officiel KINAMIXTE TECHNOLOGIE.
- Accueil, formations, programme enfants/jeunes, espace apprenant, actualités, contact et pages légales.
- Boutons d'inscription reliés au formulaire Google Forms fourni par le propriétaire.
- Liens téléphone, e-mail et WhatsApp ouverts avec les applications appropriées.
- WebView sécurisé avec JavaScript et stockage local pour les fonctions du site.
- APK DEBUG signé automatiquement pour les tests et l'installation directe.
- Workflow séparé pour produire un AAB signé destiné à Google Play.

FORMULAIRE D'INSCRIPTION
https://forms.gle/iNophpAKVfBfhtLQ6

GOOGLE PLAY
À compter du 31 août 2026, les nouvelles applications et mises à jour soumises à Google Play doivent cibler Android 16 / API 36 ou supérieur. Le projet cible donc API 36.

Pour publier sur Google Play, configurez les secrets GitHub suivants dans Settings > Secrets and variables > Actions :
- PLAY_KEYSTORE_BASE64
- PLAY_KEYSTORE_PASSWORD
- PLAY_KEY_ALIAS
- PLAY_KEY_PASSWORD

Ne mettez jamais un fichier .jks ou son mot de passe dans un dépôt public.

TEST RAPIDE
Actions > KINAMIXTE TECHNOLOGIE - APK Android > Run workflow.
Le fichier final est : app-debug.apk.

IMPORTANT
La réussite de la compilation ne remplace pas les tests sur plusieurs appareils. Avant publication, tester l'APK sur plusieurs versions Android et vérifier les liens, le formulaire, les PDF et l'affichage mobile.
