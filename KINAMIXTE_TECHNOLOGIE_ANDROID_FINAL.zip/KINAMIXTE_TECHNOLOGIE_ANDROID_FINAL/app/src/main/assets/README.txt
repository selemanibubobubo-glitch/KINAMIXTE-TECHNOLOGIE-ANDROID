KINAMIXTE TECHNOLOGIE — SITE PROFESSIONNEL COMPLET

Pages : Accueil, formations, enfants & jeunes, à propos, inscription, espace apprenant, actualités, contact, confidentialité, conditions.
Assets : logo, affiches fournies, photos du formateur, deux visuels créés pour le projet.
Documents : Guide Word et horaire Word.

MISE EN LIGNE :
Envoyer sur Netlify le dossier qui contient directement index.html, les autres fichiers HTML, assets/ et documents/.

NOTE : l'inscription est actuellement une version statique. Pour recevoir automatiquement toutes les inscriptions dans Google Sheets et administrer les apprenants, connecter ensuite le formulaire à Google Apps Script/Google Sheets.
